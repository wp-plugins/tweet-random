=== TweetRandom Plugin ===
Tags: twitter, tweet, random, complete, rss, atom, feed
Requires at least: 2.5
Tested up to: 3.0
Stable tag: 1.0

Creates an RSS feed for TweetRandom.com. 

== Description ==

TweetRandom.com is a web app from which you can tweet random stuff from your RSS/Atom feed. This plugin extends it to the Wordpress Platform. More info at http://tweetrandom.com/help.

== Installation ==
1. Unzip and copy the files to your plugins directory (/wp-content/plugins).
1. Activate the plugin.
1. Go to Settings --> TweetRandom --> "Submit your feed to TweetRandom.com"
1. Thats it!

== Frequently Asked Questions ==

= What do I do with this? =
You can Tweet Random stuff from your blog. More info at http://tweetrandom.com/help.
