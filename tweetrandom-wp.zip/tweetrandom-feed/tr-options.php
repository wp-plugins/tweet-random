<div class="wrap">
<h2><a href="http://tweetrandom.com/wordpress?feed=<?php echo str_replace('http://','', get_bloginfo( rss_url )); ?>">Submit your feed to TweetRandom.com </a> </h2>
</div>